﻿
namespace HelloWorld
{
    public class HelloWorld
    {
        public string Greet(string name)
        {
            return string.Format("Hello, {0}!", name);
        }
    }
}
