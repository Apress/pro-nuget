OctoPack has to create this file, because NuGet will only run the custom 
Install.ps1 script if a content file exists. The Install.ps1 should have 
removed this file, but since it hasn't, please delete it manually.