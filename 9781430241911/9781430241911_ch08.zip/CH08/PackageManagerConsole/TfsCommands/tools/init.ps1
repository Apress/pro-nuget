param($installPath, $toolsPath, $package)
Import-Module (Join-Path $toolsPath TfsCommands.psm1)