param($installPath, $toolsPath, $package)
Import-Module (Join-Path $toolsPath VsCommands.psm1)